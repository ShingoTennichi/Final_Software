package com.example.finalexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
