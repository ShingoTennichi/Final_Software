package com.example.finalexam.web;

import com.example.finalexam.entities.Salesman;
import com.example.finalexam.repositories.SalesRepository;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@AllArgsConstructor
public class SalesController {
    @Autowired
    private SalesRepository salesRepository;
    @GetMapping(path = "/")
    public String salesmanPage(Model model, @RequestParam(name="name",defaultValue = "") String name) {
        List<Salesman> salesmanList;

        System.out.println(name);
        // get data from database
        salesmanList = salesRepository.findAll();

        // pass the data to index.html
        model.addAttribute("salesmanList", salesmanList);

        // render
        return "index";
    }

    @PostMapping(path = "/save")
    public String save(Model model, Salesman salesman, BindingResult bindingResult, ModelMap mm, HttpSession session) {

        model.addAttribute("item", salesman);

        return "index";
    }
}