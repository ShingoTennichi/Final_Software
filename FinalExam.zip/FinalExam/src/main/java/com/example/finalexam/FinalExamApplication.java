package com.example.finalexam;

import com.example.finalexam.entities.Salesman;
import com.example.finalexam.repositories.SalesRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class FinalExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalExamApplication.class, args);
    }

    @Bean
    CommandLineRunner commandLineRunner(SalesRepository salesRepository) {
        return args -> {
            salesRepository.save(new Salesman(1, 1.0,new Date(), "item", "name"));
            System.out.println("run");
        };
    };
}
