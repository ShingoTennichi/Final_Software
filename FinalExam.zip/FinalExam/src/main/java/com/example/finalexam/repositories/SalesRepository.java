package com.example.finalexam.repositories;

import com.example.finalexam.entities.Salesman;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

public interface SalesRepository extends JpaRepository<Salesman, BigInteger> {

}
